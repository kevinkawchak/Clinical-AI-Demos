# LaTeX-Source-Files-01 - One-Page Summary of H. R. 9510

Single-column LaTeX template (number 01 of 30) for future legislative
publications, built on the open-source INSPIRATIONS: VVUQ-05/final-bill (caption + Table 1) and VVUQ-03/final-paper (back matter).

- Category: **Legislative deliverable**
- DOI placeholder: [`10.5281/zenodo.xxxxxxxx`](https://doi.org/10.5281/zenodo.xxxxxxxx) (replace `xxxxxxxx` with the Zenodo id).
- Author: Kevin Kawchak, CEO ChemicalQDevice, ORCID `0009-0007-5457-8667`.

## Files

```
LaTeX-Source-Files-01/
  main.tex            top-level document (single column)
  onepagesummarystyle.sty   style file (fonts, colors, macros)
  references.bib      bibliography (ieeetr)
  README.md           this file
  orcid_icon.png      green ORCID logo (rule 8)
  sections/
    section-a.tex ... section-f.tex
```

## One section file per document section

This template uses **one `section-x.tex` file per document section** (rule 9).
Add another document section by adding `sections/section-g.tex` and an
`\input{sections/section-g}` line in `main.tex`.

| Section file | Document section |
|:--|:--|
| `sections/section-a.tex` | PURPOSE AND SCOPE. |
| `sections/section-b.tex` | BACKGROUND AND FIGURE. |
| `sections/section-c.tex` | RECORD AT A GLANCE. |
| `sections/section-d.tex` | ANALYSIS. |
| `sections/section-e.tex` | CONCLUSION. |
| `sections/section-f.tex` | BACK MATTER. |

## What is included (per the rules)

- One **image placeholder** in `section-b.tex`, based on the figure code of
  `cancer-automated/papers/VVUQ-02/final-paper`.
- One **table** in `section-c.tex`, modeled on **Table 1** of
  `cancer-automated/papers/VVUQ-05/final-bill`.
- The **back matter** in `section-f.tex` (Acknowledgments, Ethical Disclosures,
  Rights and Permissions, Cite This Summary, Data Availability), adapted from
  `cancer-automated/papers/VVUQ-03/final-paper`.
- A **blank Keywords line** on the first page (fill in, separated by `|`).
- The properly placed **DOI** `10.5281/zenodo.xxxxxxxx` on the cover and in the citation block.
- The green **ORCID logo** (`orcid_icon.png`) on the cover in place of the green
  `iD` text.

## Compile (Overleaf, pdfLaTeX)

```
pdflatex main
bibtex   main
pdflatex main
pdflatex main
```

## License

Released under CC BY 4.0. Reproduced public-domain U.S. Government text is used
under 17 U.S.C. § 105.
