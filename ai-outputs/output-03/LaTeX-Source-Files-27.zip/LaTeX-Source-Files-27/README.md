# LaTeX-Source-Files-27

**Verification Before Generation Standard** -- a single-column LaTeX template (number 27 of 30) in the *VVUQ* family.

- **Genre / perspective:** Standards-body document (numbered clauses).
- **Built on INSPIRATIONS:** VVUQ-01..04; VVUQ-05 Table 1; VVUQ-03 back matter.
- **Body style:** Kp-Fonts.
- **DOI placeholder:** [`10.5281/zenodo.xxxxxxxx`](https://doi.org/10.5281/zenodo.xxxxxxxx) (replace `xxxxxxxx`).
- **Author:** Kevin Kawchak, CEO ChemicalQDevice, ORCID `0009-0007-5457-8667`.

## Files

```
LaTeX-Source-Files-27/
  main.tex
  tmpl27style.sty
  references.bib
  README.md
  orcid_icon.png
  sections/
    section-a.tex
    section-b.tex
    section-c.tex
    section-d.tex
    section-e.tex
    section-f.tex
```

## One section file per document section

This template uses **one `section-x.tex` file per document section** (rule 9); add a section by adding `sections/section-g.tex` and an `\input` line in `main.tex`.

| Section file | Document section |
|:--|:--|
| `sections/section-a.tex` | 1 Scope |
| `sections/section-b.tex` | 2 Normative references |
| `sections/section-c.tex` | 3 Terms and definitions |
| `sections/section-d.tex` | 4 Requirements |
| `sections/section-e.tex` | 5 Conformance |
| `sections/section-f.tex` | Back matter (VVUQ-03) |

## Included per the rules

- One **image placeholder** based on the figure code of `papers/VVUQ-02/final-paper`.
- One **table** modeled on **Table 1** of `papers/VVUQ-05/final-bill`.
- The **back matter** from `papers/VVUQ-03/final-paper` (the parts that fit this genre).
- A **blank Keywords line** on the first page; the **DOI** on the cover and in the citation block.
- The green **ORCID logo** (`orcid_icon.png`) on the cover in place of the green `iD` text.

## Compile (Overleaf, pdfLaTeX)

```
pdflatex main
bibtex   main
pdflatex main
pdflatex main
```

## License

CC BY 4.0. Reproduced public-domain U.S. Government text is used under 17 U.S.C. § 105.
